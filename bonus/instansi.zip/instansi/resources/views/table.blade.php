<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your App Name</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
    <!-- Add any additional styles or scripts here -->
</head>
<body>
    <section class="section">
        <div class="container">
            <h1 class="title">Instansi List</h1>
            <table class="table is-fullwidth">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Instansi</th>
                        <th>Deskripsi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($instansiData as $key => $instansi)
                    <tr>
                        <td>{{ $key + 1 }}</td>
                        <td>{{ $instansi->nama_instansi }}</td>
                        <td>{{ $instansi->deskripsi }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </section>
</body>
</html>
