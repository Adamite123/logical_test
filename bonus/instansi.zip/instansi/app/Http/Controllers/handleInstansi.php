<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class handleInstansi extends Controller
{

    public function index()
    {
        $instansiData = DB::table('instansi')->get();

        return view('table', compact('instansiData'));
    }


    public function login(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');
    
        $user = DB::table('user')->where('username', $username)->first();
    
        if ($user->username == $user->password) {
            return redirect()->intended('/dashboard'); 
        }
    
        dd($username);
        return redirect()->intended('/'); 
    }

    public function submit(Request $request)
    {
        $validatedData = $request->validate([
            'instansi' => 'required|string|max:255',
            'deskripsi' => 'required|string',
        ]);

        DB::table('instansi')->insert([
            'nama_instansi' => $validatedData['instansi'],
            'deskripsi' => $validatedData['deskripsi'],
        ]);

        return redirect()->intended('/show'); 
    }
}
