<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your App Name</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
    <!-- Add any additional styles or scripts here -->
</head>
<body>
    <section class="section">
        <div class="container">
            <h1 class="title">Instansi List</h1>
            <table class="table is-fullwidth">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Instansi</th>
                        <th>Deskripsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $instansiData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $instansi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($instansi->nama_instansi); ?></td>
                        <td><?php echo e($instansi->deskripsi); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/instansi/resources/views/table.blade.php ENDPATH**/ ?>